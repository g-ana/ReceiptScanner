import {Receipt} from "../classes/Receipt";

export interface ScannerInterface {
    scanReceipt(): Promise<Receipt | void>;
}