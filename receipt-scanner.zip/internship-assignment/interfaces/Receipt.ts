import {ProductOrigin} from "../enumerations/ProductOrigin";
import {Product} from "../classes/Product";
import {ProductType} from "../types/Product";

export interface ReceiptInterface {
    groupProductsByOrigin(): Map<ProductOrigin, Array<ProductType>>;
    getDomesticProducts(): Array<ProductType>;
    getImportedProducts(): Array<ProductType>;
    countPurchasedProductsByOrigin(origin: ProductOrigin) : Number;
    calculateTotalPriceByOrigin(origin: ProductOrigin) : Number;
}