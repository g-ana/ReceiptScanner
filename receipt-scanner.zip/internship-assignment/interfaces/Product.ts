export interface ProductInterface {
    formatDescription(): String;
    formatWeight(): String;
    formatPrice(): String;
}