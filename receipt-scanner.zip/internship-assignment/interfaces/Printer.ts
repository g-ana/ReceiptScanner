import {Product} from "../classes/Product";
import {Receipt} from "../classes/Receipt";

export interface PrinterInterface {
    formatItemDetails(product: Product);
    formatReceiptDetails(receipt: Receipt);
}