import {PrinterInterface} from "../interfaces/Printer";
import {Product} from "./Product";
import {Receipt} from "./Receipt";
import {ProductOrigin} from "../enumerations/ProductOrigin";

export class Printer implements PrinterInterface {
    public formatItemDetails = (product: Product): String => {
        return `${'.'.repeat(3)} 
                ${product?.name
            .padStart(product?.name?.length + 2, "  ")}\n
                ${product?.formatPrice()
            .padStart(product?.formatPrice()?.length + 2, "  ")}
                ${product?.formatDescription()
            .padStart(product?.formatDescription()?.length + 2, "  ")}\n
                ${product?.formatWeight()
            .padStart(product?.formatWeight()?.length + 2, "  ")}\n`?? "";
    }

    public formatReceiptDetails = (receipt: Receipt): String => {
        return `${".".repeat(1)}
                Domestic\n
                ${receipt?.getDomesticProducts()
                    ?.forEach((item, index) => this.formatItemDetails(item))}
                ${".".repeat(1)}
                Imported\n
                ${receipt?.getImportedProducts()
                    ?.forEach((item, index) => this.formatItemDetails(item))}
                Domestic cost: $
                ${receipt?.calculateTotalPriceByOrigin(ProductOrigin.DOMESTIC).toFixed(1)}\n
                Imported cost: $
                ${receipt?.calculateTotalPriceByOrigin(ProductOrigin.IMPORTED).toFixed(1)}\n
                Domestic count: 
                ${receipt?.countPurchasedProductsByOrigin(ProductOrigin.DOMESTIC)}\n
                Imported count: 
                ${receipt?.countPurchasedProductsByOrigin(ProductOrigin.IMPORTED)}` ?? "";
    }
}