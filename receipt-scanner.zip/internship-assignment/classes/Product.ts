import {ProductInterface} from "../interfaces/Product";
import {ProductType} from "../types/Product";

export class Product implements ProductType, ProductInterface {
    description?: String;
    isDomestic?: Boolean;
    name?: String;
    price?: Number;
    weight?: Number;
    public constructor(name: String = "",
                       description: String = "",
                       isDomestic: Boolean = false,
                       price: Number = 0.0,
                       weight: Number = 0) {
        this.name = name;
        this.description = description;
        this.isDomestic = isDomestic;
        this.price = price;
        this.weight = weight;
    }
    public formatDescription = (): String =>
        `${this.description.length > 10 ? 
            this.description.slice(0,10).padEnd(13, "...") :
            this.description}`;
    public formatPrice = (): String => `Price $${this.price.toFixed(1)}`;
    public formatWeight = (): String => `Weight: ${this.weight?.toString()}g` ?? "N/A";
}