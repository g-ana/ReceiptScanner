import {ScannerInterface} from "../interfaces/Scanner";
import {ScannerType} from "../types/Scanner";
import {Receipt} from "./Receipt";
import {Product} from "./Product";

export class Scanner implements ScannerType, ScannerInterface {
    baseUrl?: String;
    relativeUrl?: String;
    retrieveFromUrl?: URL;

    public constructor(baseUrl: String = "https://interview-task-api.mca.dev/",
                       relativeUrl: String = "qr-scanner-codes/alpha-qr-gFpwhsQ8fkY1",
                       retrieveFromUrl: URL = new URL(relativeUrl.valueOf(), baseUrl.valueOf())) {
        this.baseUrl = baseUrl;
        this.relativeUrl = relativeUrl;
        this.retrieveFromUrl = new URL(this.relativeUrl.valueOf(), this.baseUrl.valueOf());
    }

    public async scanReceipt(): Promise<Receipt | void> {
        return await fetchData()
            .then(response => {
                console.assert(response);
                console.dir(response);
                const items: Array<Product> = [];
                for (let responseKey in response) {
                    let p: Product = new Product();
                    p = (response[responseKey] as unknown) as Product;
                    items.push(p);
                }
                /*
                const products : Array<Product> = response.items?.map(p =>
                    new Product(p.name, p.description, p.isDomestic, p.price, p.weight)
                );
                return new Receipt(products); */
                return new Receipt(items);
            })
           .catch(error =>
                console.error(`${error.errorCode} - 
                ${error.errorText}\n 
                ${error.errorDetail}`)
            );
            }
    }
export const fetchData = async () : Promise<Receipt> => {
    const response = await fetch("https://interview-task-api.mca.dev/qr-scanner-codes/alpha-qr-gFpwhsQ8fkY1");
    try {
    /*    console.assert(response.ok, response);
        console.info(`${response.type}\n 
                    ${response.status} - 
                    ${response.statusText}`); */
        return await response.json();
    }
    catch (error) {
        console.error(`${error.errorCode} - 
            ${error.errorText}\n 
            ${error.errorDetail}`);
        return error;
    }
}