"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Printer = void 0;
const ProductOrigin_1 = require("../enumerations/ProductOrigin");
class Printer {
    formatItemDetails = (product) => {
        return `${'.'.repeat(3)} 
                ${product?.name
            .padStart(product?.name?.length + 2, "  ")}\n
                ${product?.formatPrice()
            .padStart(product?.formatPrice()?.length + 2, "  ")}
                ${product?.formatDescription()
            .padStart(product?.formatDescription()?.length + 2, "  ")}\n
                ${product?.formatWeight()
            .padStart(product?.formatWeight()?.length + 2, "  ")}\n` ?? "";
    };
    formatReceiptDetails = (receipt) => {
        return `${".".repeat(1)}
                Domestic\n
                ${receipt?.getDomesticProducts()
            ?.forEach((item, index) => this.formatItemDetails(item))}
                ${".".repeat(1)}
                Imported\n
                ${receipt?.getImportedProducts()
            ?.forEach((item, index) => this.formatItemDetails(item))}
                Domestic cost: $
                ${receipt?.calculateTotalPriceByOrigin(ProductOrigin_1.ProductOrigin.DOMESTIC).toFixed(1)}\n
                Imported cost: $
                ${receipt?.calculateTotalPriceByOrigin(ProductOrigin_1.ProductOrigin.IMPORTED).toFixed(1)}\n
                Domestic count: 
                ${receipt?.countPurchasedProductsByOrigin(ProductOrigin_1.ProductOrigin.DOMESTIC)}\n
                Imported count: 
                ${receipt?.countPurchasedProductsByOrigin(ProductOrigin_1.ProductOrigin.IMPORTED)}` ?? "";
    };
}
exports.Printer = Printer;
//# sourceMappingURL=Printer.js.map