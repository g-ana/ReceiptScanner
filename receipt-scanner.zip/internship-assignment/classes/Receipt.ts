import {ReceiptType} from "../types/Receipt";
import {ReceiptInterface} from "../interfaces/Receipt";
import {ProductOrigin} from "../enumerations/ProductOrigin";
import {ProductType} from "../types/Product";
import {Product} from "./Product";

export class Receipt implements ReceiptType, ReceiptInterface {
    items: Array<Product>;
    public constructor(items: Array<Product> = []) {
        this.items = items;
    }
    public calculateTotalPriceByOrigin = (origin: ProductOrigin): Number =>
        origin === ProductOrigin.DOMESTIC ?
            this.getDomesticProducts()
                .map(item => item.price)
                .reduce((p1, p2) => p1.valueOf() + p2.valueOf(), 0) :
            this.getImportedProducts()
                .map(item => item.price)
                .reduce((p1, p2) => p1.valueOf() + p2.valueOf(), 0);
    public countPurchasedProductsByOrigin = (origin: ProductOrigin): Number =>
        origin === ProductOrigin.DOMESTIC ?
            this.getDomesticProducts().length :
            this.getImportedProducts().length;
    public getDomesticProducts = (): Array<Product> =>
        this.groupProductsByOrigin().get(ProductOrigin.DOMESTIC);

    public getImportedProducts = (): Array<Product> =>
        this.groupProductsByOrigin().get(ProductOrigin.IMPORTED);
    public groupProductsByOrigin(): Map<ProductOrigin, Array<Product>> {
        const productsByOrigin = new Map<ProductOrigin, Array<Product>>();
        productsByOrigin.set(ProductOrigin.IMPORTED, []);
        const domestic : Array<Product> = this.sortItemsAlphabetically(
            this.items?.filter(item => item.isDomestic)
        );
        const imported : Array<Product> = this.sortItemsAlphabetically(
            this.items?.filter(item => !item.isDomestic)
        );
        productsByOrigin.set(ProductOrigin.DOMESTIC, domestic);
        productsByOrigin.set(ProductOrigin.IMPORTED, imported);
        return productsByOrigin;
    }
    private sortItemsAlphabetically = (items: Array<Product>): Array<Product> =>
        items.sort((item1, item2) =>
            item1.name.localeCompare(item2.name.valueOf()));
    }