"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Receipt = void 0;
const ProductOrigin_1 = require("../enumerations/ProductOrigin");
class Receipt {
    items;
    constructor(items = []) {
        this.items = items;
    }
    calculateTotalPriceByOrigin = (origin) => origin === ProductOrigin_1.ProductOrigin.DOMESTIC ?
        this.getDomesticProducts()
            .map(item => item.price)
            .reduce((p1, p2) => p1.valueOf() + p2.valueOf(), 0) :
        this.getImportedProducts()
            .map(item => item.price)
            .reduce((p1, p2) => p1.valueOf() + p2.valueOf(), 0);
    countPurchasedProductsByOrigin = (origin) => origin === ProductOrigin_1.ProductOrigin.DOMESTIC ?
        this.getDomesticProducts().length :
        this.getImportedProducts().length;
    getDomesticProducts = () => this.groupProductsByOrigin().get(ProductOrigin_1.ProductOrigin.DOMESTIC);
    getImportedProducts = () => this.groupProductsByOrigin().get(ProductOrigin_1.ProductOrigin.IMPORTED);
    groupProductsByOrigin() {
        const productsByOrigin = new Map();
        productsByOrigin.set(ProductOrigin_1.ProductOrigin.IMPORTED, []);
        const domestic = this.sortItemsAlphabetically(this.items?.filter(item => item.isDomestic));
        const imported = this.sortItemsAlphabetically(this.items?.filter(item => !item.isDomestic));
        productsByOrigin.set(ProductOrigin_1.ProductOrigin.DOMESTIC, domestic);
        productsByOrigin.set(ProductOrigin_1.ProductOrigin.IMPORTED, imported);
        return productsByOrigin;
    }
    sortItemsAlphabetically = (items) => items.sort((item1, item2) => item1.name.localeCompare(item2.name.valueOf()));
}
exports.Receipt = Receipt;
//# sourceMappingURL=Receipt.js.map