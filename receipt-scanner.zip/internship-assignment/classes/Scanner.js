"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchData = exports.Scanner = void 0;
const Receipt_1 = require("./Receipt");
const Product_1 = require("./Product");
class Scanner {
    baseUrl;
    relativeUrl;
    retrieveFromUrl;
    constructor(baseUrl = "https://interview-task-api.mca.dev/", relativeUrl = "qr-scanner-codes/alpha-qr-gFpwhsQ8fkY1", retrieveFromUrl = new URL(relativeUrl.valueOf(), baseUrl.valueOf())) {
        this.baseUrl = baseUrl;
        this.relativeUrl = relativeUrl;
        this.retrieveFromUrl = new URL(this.relativeUrl.valueOf(), this.baseUrl.valueOf());
    }
    async scanReceipt() {
        return await (0, exports.fetchData)()
            .then(response => {
            console.assert(response);
            console.dir(response);
            const items = [];
            for (let responseKey in response) {
                let p = new Product_1.Product();
                p = response[responseKey];
                items.push(p);
            }
            /*
            const products : Array<Product> = response.items?.map(p =>
                new Product(p.name, p.description, p.isDomestic, p.price, p.weight)
            );
            return new Receipt(products); */
            return new Receipt_1.Receipt(items);
        })
            .catch(error => console.error(`${error.errorCode} - 
                ${error.errorText}\n 
                ${error.errorDetail}`));
    }
}
exports.Scanner = Scanner;
const fetchData = async () => {
    const response = await fetch("https://interview-task-api.mca.dev/qr-scanner-codes/alpha-qr-gFpwhsQ8fkY1");
    try {
        /*    console.assert(response.ok, response);
            console.info(`${response.type}\n
                        ${response.status} -
                        ${response.statusText}`); */
        return await response.json();
    }
    catch (error) {
        console.error(`${error.errorCode} - 
            ${error.errorText}\n 
            ${error.errorDetail}`);
        return error;
    }
};
exports.fetchData = fetchData;
//# sourceMappingURL=Scanner.js.map