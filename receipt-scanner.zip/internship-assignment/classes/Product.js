"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Product = void 0;
class Product {
    description;
    isDomestic;
    name;
    price;
    weight;
    constructor(name = "", description = "", isDomestic = false, price = 0.0, weight = 0) {
        this.name = name;
        this.description = description;
        this.isDomestic = isDomestic;
        this.price = price;
        this.weight = weight;
    }
    formatDescription = () => `${this.description.length > 10 ?
        this.description.slice(0, 10).padEnd(13, "...") :
        this.description}`;
    formatPrice = () => `Price $${this.price.toFixed(1)}`;
    formatWeight = () => `Weight: ${this.weight?.toString()}g` ?? "N/A";
}
exports.Product = Product;
//# sourceMappingURL=Product.js.map