"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Scanner_1 = require("./classes/Scanner");
const Printer_1 = require("./classes/Printer");
const main = async () => {
    const scanner = new Scanner_1.Scanner();
    const printer = new Printer_1.Printer();
    const receipt = await scanner.scanReceipt()
        .then(receipt => {
        console.log("Receipt:", { ...receipt });
        console.info(printer.formatReceiptDetails(receipt));
    })
        .catch(error => console.error(`${error.errorCode} - 
                ${error.errorText}\n 
                ${error.errorDetail}`));
};
main();
//# sourceMappingURL=main.js.map