export type ScannerType = {
    baseUrl?: String;
    relativeUrl?: String;
    retriveFromUrl?: URL;
}