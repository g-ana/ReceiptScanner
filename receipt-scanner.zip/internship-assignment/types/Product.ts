export type ProductType = {
    name?: String;
    description?: String;
    isDomestic?: Boolean;
    price?: Number;
    weight?: Number;

}