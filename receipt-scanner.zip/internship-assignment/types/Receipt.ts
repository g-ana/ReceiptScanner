import {ProductType} from "./Product";
import {Product} from "../classes/Product";

export type ReceiptType = {
    items?: Array<Product>;
}