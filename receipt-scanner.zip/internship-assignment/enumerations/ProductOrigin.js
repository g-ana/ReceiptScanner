"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductOrigin = void 0;
var ProductOrigin;
(function (ProductOrigin) {
    ProductOrigin[ProductOrigin["DOMESTIC"] = 0] = "DOMESTIC";
    ProductOrigin[ProductOrigin["IMPORTED"] = 1] = "IMPORTED";
})(ProductOrigin = exports.ProductOrigin || (exports.ProductOrigin = {}));
//# sourceMappingURL=ProductOrigin.js.map