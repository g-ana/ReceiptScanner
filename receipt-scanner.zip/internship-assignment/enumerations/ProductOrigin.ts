export enum ProductOrigin {
    DOMESTIC,
    IMPORTED,
}