import {Scanner, fetchData} from "./classes/Scanner";
import {Printer} from "./classes/Printer";
import {Receipt} from "./classes/Receipt";
import {Product} from "./classes/Product";

const main = async (): Promise<Receipt | void> => {
    const scanner : Scanner = new Scanner();
    const printer : Printer = new Printer();
    const receipt : Receipt | void = await scanner.scanReceipt()
        .then(receipt => {
            console.log("Receipt:", {...receipt});
            console.info(printer.formatReceiptDetails((receipt as Receipt)));
        })
    .catch(error =>
        console.error(`${error.errorCode} - 
                ${error.errorText}\n 
                ${error.errorDetail}`)
    );
};
main();

